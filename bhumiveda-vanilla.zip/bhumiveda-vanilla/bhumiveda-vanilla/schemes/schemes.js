/* ============================================================
   SCHEMES.JS — category filter + search + render scheme cards.
   ============================================================ */
window.addEventListener("bv-shell-ready", () => {
  const D = window.BV_DATA;
  const cats = ["All", "Financial Aid", "Insurance", "Advisory", "Infrastructure"];
  let selected = "All";
  let query = "";

  const catsEl = document.getElementById("bv-cats");
  const listEl = document.getElementById("bv-schemes");
  const searchEl = document.getElementById("bv-search");

  function renderCats() {
    catsEl.innerHTML = cats.map(c => `<button class="bv-cat ${c === selected ? "active" : ""}" data-cat="${c}">${c}</button>`).join("");
  }

  function renderList() {
    const filtered = D.schemes.filter(s =>
      (selected === "All" || s.category === selected) &&
      s.name.toLowerCase().includes(query.toLowerCase())
    );
    listEl.innerHTML = filtered.map(s => `
      <div class="bv-scheme bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl p-6 shadow-sm">
        <div class="flex items-start justify-between mb-3">
          <div class="flex-1">
            <div class="flex items-center gap-2 flex-wrap mb-1">
              <h3 class="font-bold text-gray-900 dark:text-white">${s.name}</h3>
              ${s.eligible
                ? `<span class="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1"><i data-lucide="check-circle" style="width:10px;height:10px"></i>Eligible</span>`
                : `<span class="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1"><i data-lucide="alert-triangle" style="width:10px;height:10px"></i>Not Eligible</span>`}
              ${s.applied ? `<span class="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-semibold">Applied ✓</span>` : ""}
            </div>
            <div class="text-xs text-gray-500 dark:text-gray-400">${s.ministry}</div>
          </div>
          <span class="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full font-medium">${s.category}</span>
        </div>
        <p class="text-sm text-gray-500 dark:text-gray-400 leading-relaxed mb-4">${s.description}</p>
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-4">
            <div>
              <div class="text-xs text-gray-500 dark:text-gray-400">Benefit</div>
              <div class="text-sm font-bold text-green-600">${s.benefit}</div>
            </div>
            <div>
              <div class="text-xs text-gray-500 dark:text-gray-400">Deadline</div>
              <div class="text-sm font-bold flex items-center gap-1 ${s.deadline === "Ongoing" ? "text-blue-600" : "text-orange-500"}">
                <i data-lucide="clock" style="width:12px;height:12px"></i>${s.deadline}
              </div>
            </div>
          </div>
          <button ${(!s.eligible || s.applied) ? "disabled" : ""}
            class="px-4 py-2 rounded-xl text-sm font-bold transition-colors ${s.applied ? "bg-blue-100 text-blue-700 cursor-default" : s.eligible ? "bg-green-600 text-white hover:bg-green-700 shadow-sm" : "bg-gray-100 text-gray-400 cursor-not-allowed"}">
            ${s.applied ? "Applied ✓" : s.eligible ? "Apply Now →" : "Not Eligible"}
          </button>
        </div>
      </div>
    `).join("") || `<p class="text-sm text-gray-500 col-span-full">No schemes match your filters.</p>`;
    window.lucide && window.lucide.createIcons();
  }

  catsEl.addEventListener("click", e => {
    const b = e.target.closest("[data-cat]");
    if (!b) return;
    selected = b.dataset.cat;
    renderCats(); renderList();
  });
  searchEl.addEventListener("input", e => { query = e.target.value; renderList(); });

  renderCats(); renderList();
});
