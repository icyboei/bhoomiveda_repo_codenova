/* ============================================================
   SHELL.JS — Code that runs on every page.
   Responsibilities:
     1. Load reusable HTML partials (navbar, sidebar, AI button).
     2. Manage dark mode (toggled by the navbar button, persisted
        in localStorage so the choice survives reloads).
     3. Highlight the active sidebar link.
     4. Wire up the mobile menu open/close.
   ============================================================ */

(function () {
  // --- Dark mode helpers -------------------------------------------------
  function applyDarkPref() {
    const wantDark = localStorage.getItem("bv-dark") === "1";
    document.documentElement.classList.toggle("dark", wantDark);
  }
  applyDarkPref();
  window.bvToggleDark = function () {
    const isDark = !document.documentElement.classList.contains("dark");
    document.documentElement.classList.toggle("dark", isDark);
    localStorage.setItem("bv-dark", isDark ? "1" : "0");
    window.dispatchEvent(new Event("bv-dark-changed"));
  };

  // --- Partial loader: replaces every <div data-include="path"> with HTML
  async function loadPartials() {
    const slots = document.querySelectorAll("[data-include]");
    await Promise.all(Array.from(slots).map(async (slot) => {
      try {
        const res = await fetch(slot.getAttribute("data-include"));
        slot.innerHTML = await res.text();
      } catch (err) {
        console.warn("Failed to load partial:", err);
      }
    }));
    // Re-render icons after partials are injected
    if (window.lucide) window.lucide.createIcons();
    // Tell other scripts the shell is ready
    window.dispatchEvent(new Event("bv-shell-ready"));
  }

  // Run after DOM ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", loadPartials);
  } else {
    loadPartials();
  }
})();
