/* Paste your Google Maps API key below to enable GPS + weather auto-fetch
   on the AI Crop Advisor page. Without a key the form still works manually. */
window.BV_CONFIG = {
  GOOGLE_MAPS_API_KEY: "your_google_maps_api_key_here",
};
