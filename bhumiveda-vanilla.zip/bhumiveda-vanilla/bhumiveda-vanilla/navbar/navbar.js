/* ============================================================
   NAVBAR.JS
     - Updates the page title shown in the top bar.
     - Wires dark mode toggle to the global shell helper.
     - Toggles notifications dropdown and fills it from data.js.
   ============================================================ */
window.addEventListener("bv-shell-ready", () => {
  const titleEl = document.getElementById("bv-page-title");
  if (titleEl && document.body.dataset.pageTitle) {
    titleEl.textContent = document.body.dataset.pageTitle;
  }

  const darkBtn = document.getElementById("bv-dark-toggle");
  if (darkBtn) darkBtn.addEventListener("click", () => window.bvToggleDark());

  // Notifications dropdown
  const btn   = document.getElementById("bv-notif-btn");
  const panel = document.getElementById("bv-notif-panel");
  const list  = document.getElementById("bv-notif-list");
  if (!btn || !panel || !list) return;

  const bgByType = { warning: "bg-yellow-50", success: "bg-green-50", info: "bg-blue-50", ai: "bg-purple-50" };
  const dotByType = { warning: "bg-yellow-400", success: "bg-green-500", info: "bg-blue-400", ai: "bg-purple-400" };

  list.innerHTML = window.BV_DATA.notifications.map(n => `
    <div class="px-4 py-3 border-b border-gray-100 dark:border-gray-700 ${bgByType[n.type]} dark:bg-transparent hover:brightness-95 dark:hover:bg-gray-700 transition-colors cursor-pointer last:border-0">
      <div class="flex items-start gap-2">
        <div class="w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${dotByType[n.type]}"></div>
        <div>
          <div class="text-sm font-semibold text-gray-900 dark:text-white">${n.title}</div>
          <div class="text-xs text-gray-500 dark:text-gray-400 mt-0.5">${n.desc}</div>
          <div class="text-xs text-gray-400 mt-1">${n.time} ago</div>
        </div>
      </div>
    </div>
  `).join("");

  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    panel.classList.toggle("hidden");
  });
  document.addEventListener("click", (e) => {
    if (!panel.contains(e.target) && !btn.contains(e.target)) panel.classList.add("hidden");
  });
});
