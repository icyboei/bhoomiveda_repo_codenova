/* ============================================================
   SIDEBAR.JS — highlights the current page link and lets the
   user collapse the sidebar to icons only.
   ============================================================ */
window.addEventListener("bv-shell-ready", () => {
  const current = document.body.dataset.page;
  document.querySelectorAll("[data-nav]").forEach(a => {
    if (a.dataset.nav === current) a.classList.add("active");
  });

  const aside = document.getElementById("bv-sidebar");
  const btn   = document.getElementById("bv-sidebar-collapse");
  if (btn && aside) {
    btn.addEventListener("click", () => aside.classList.toggle("collapsed"));
  }
});
