/* ============================================================
   PROFILE.JS — renders farm details, productivity stats,
   achievements, line chart, and wires the "Edit Profile" modal.
   ============================================================ */
window.addEventListener("bv-shell-ready", () => {
  const D = window.BV_DATA;

  const farm = [
    { label: "Land Size",    value: "12 acres" },
    { label: "Soil Type",    value: "Black Cotton" },
    { label: "Water Source", value: "Borewell + Canal" },
    { label: "Location",     value: "Vidisha, MP" },
    { label: "Crops Grown",  value: "Wheat, Soybean" },
    { label: "Season",       value: "Kharif + Rabi" },
  ];
  document.getElementById("bv-farm").innerHTML = farm.map(i => `
    <div class="flex justify-between">
      <span class="text-sm text-gray-500 dark:text-gray-400">${i.label}</span>
      <span class="text-sm font-semibold text-gray-900 dark:text-white">${i.value}</span>
    </div>
  `).join("");

  const stats = [
    { v: "28%",   l: "Yield Increase", c: "text-green-600" },
    { v: "₹2.8L", l: "Annual Revenue", c: "text-blue-600" },
    { v: "18%",   l: "Water Savings",  c: "text-cyan-600" },
    { v: "94%",   l: "AI Accuracy",    c: "text-purple-600" },
  ];
  document.getElementById("bv-stats").innerHTML = stats.map(s => `
    <div class="bg-gray-50 dark:bg-gray-700 rounded-xl p-3 text-center">
      <div class="text-xl font-black ${s.c}">${s.v}</div>
      <div class="text-xs text-gray-500 dark:text-gray-400 mt-0.5">${s.l}</div>
    </div>
  `).join("");

  const badges = [
    { icon: "🏆", name: "Top Farmer",       desc: "Week of May 2025" },
    { icon: "🌾", name: "Harvest Master",   desc: "3 successful harvests" },
    { icon: "💧", name: "Water Saver",      desc: "20% below average" },
    { icon: "🤖", name: "AI Pioneer",       desc: "First 1000 AI users" },
    { icon: "🤝", name: "Community Star",   desc: "100+ helpful posts" },
    { icon: "📊", name: "Data Driven",      desc: "30 days tracked" },
  ];
  document.getElementById("bv-badges").innerHTML = badges.map(b => `
    <div class="bv-badge bg-gray-50 dark:bg-gray-700 rounded-xl p-2.5 text-center cursor-pointer group">
      <div class="text-2xl mb-1">${b.icon}</div>
      <div class="text-xs font-semibold text-gray-900 dark:text-white group-hover:text-yellow-600 transition-colors">${b.name}</div>
      <div class="text-xs text-gray-500 dark:text-gray-400 mt-0.5 leading-tight">${b.desc}</div>
    </div>
  `).join("");

  window.lucide && window.lucide.createIcons();

  // Productivity chart
  new Chart(document.getElementById("bv-profile-chart"), {
    type: "line",
    data: {
      labels: D.marketData.map(m => m.month),
      datasets: [{ data: D.marketData.map(m => m.wheat), borderColor: "#2E7D32", borderWidth: 2, pointRadius: 0, tension: .35 }],
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
      scales: { x: { display: false }, y: { display: false } } },
  });

  // Modal logic
  const modal = document.getElementById("bv-edit-modal");
  const fieldsEl = document.getElementById("bv-edit-fields");
  const open  = () => modal.classList.remove("hidden");
  const close = () => modal.classList.add("hidden");

  fieldsEl.innerHTML = [
    { l: "Full Name",         v: "Rajendra Jatav" },
    { l: "Location",          v: "Vidisha, MP" },
    { l: "Land Size (acres)", v: "12" },
    { l: "Primary Crop",      v: "Wheat, Soybean" },
  ].map(f => `
    <div>
      <label class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider block mb-1.5">${f.l}</label>
      <input value="${f.v}" class="w-full rounded-xl border px-4 py-2.5 text-sm outline-none bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600 text-gray-900 dark:text-white focus:border-green-500 transition-colors" />
    </div>
  `).join("");

  document.getElementById("bv-edit-open").addEventListener("click", open);
  document.getElementById("bv-edit-close").addEventListener("click", close);
  document.getElementById("bv-edit-cancel").addEventListener("click", close);
  document.getElementById("bv-edit-save").addEventListener("click", close);
  modal.addEventListener("click", (e) => { if (e.target === modal) close(); });
});
