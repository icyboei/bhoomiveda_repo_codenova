# BhoomiVeda
This is a smart AI powered crop recommendation project.
Author - CodeNova
Hackathon

